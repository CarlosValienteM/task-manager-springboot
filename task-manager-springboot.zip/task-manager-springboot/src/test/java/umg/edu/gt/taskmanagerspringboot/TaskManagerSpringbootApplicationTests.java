package umg.edu.gt.taskmanagerspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagerSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
